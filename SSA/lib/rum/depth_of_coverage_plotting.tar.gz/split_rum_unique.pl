#!/usr/bin/perl

# Written by Gregory R. Grant
# University of Pennsylvania, 2010

if(@ARGV < 2) {
    die "
Usage: merge_rum_unique_files.pl <rum unique file> <num chunks>
";
}

use IO::File;

$num_chunks = $ARGV[1];
$RUM_file = $ARGV[0];
$t = `tail -1 $RUM_file`;
$t =~ /seq.(\d+)/;
$last_seq_num = $1;
$chunk_size = int($last_seq_num / $num_chunks);

print STDERR "Breaking $ARGV[0] into $num_chunks pieces, each of size $chunk_size...\n";

for($i=1; $i<=$num_chunks; $i++) {
    $outfilename = "RUM_Unique_split." . $i;
    $handle_name[$i] = OUTFILE . "$i";
    $handle[$i] = IO::File->new();
    open($handle[$i], '>', $outfilename);
}

open(INFILE, $ARGV[0]);
while($line = <INFILE>) {
    $line =~ /seq.(\d+)/;
    $seqnum = $1;
    $filenum = int($seqnum / $chunk_size) + 1;
    if($filenum > $num_chunks) {
	$filenum = $num_chunks;
    }
    $h = $handle[$filenum];
    print $h $line;
}
close(INFILE);

for($i=1; $i<=$num_chunks; $i++) {
    $outfilename = "RUM_Unique_split." . $i;
    $h = $handle[$i];
    close($h);
}

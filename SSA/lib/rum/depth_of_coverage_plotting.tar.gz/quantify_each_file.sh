for i in {1..10}
do
   perl quantify_one_sample.pl RUM_Unique_split.$i.cov GENE_INFO_FILE -zero -open > feature_quantifications.split.$i.txt
done

for i in {1..10}
do
    java -Xmx2000m M2C RUM_Unique_split.$i.bed RUM_Unique_split.$i.cov temp.log -name "Split $i" -ucsc
done

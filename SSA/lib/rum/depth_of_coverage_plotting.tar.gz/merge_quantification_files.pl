#!/usr/bin/perl

# Written by Gregory R. Grant
# University of Pennsylvania, 2010

if(@ARGV < 2) {
    die "
Usage: merge_quantification_files.pl <quant file 1> <quant file 2>

";
}

open(INFILE1, $ARGV[0]);
open(INFILE2, $ARGV[1]);
$num_bases1 = <INFILE1>;
chomp($num_bases1);
until($num_bases1 =~ /basereads/) {
    $num_bases1 = <INFILE1>;    
    chomp($num_bases1);
}
$num_bases1 =~ s/[^\d]//g;
print STDERR "num_bases1 = $num_bases1\n";
$num_bases2 = <INFILE2>;
chomp($num_bases2);
until($num_bases2 =~ /basereads/) {
    $num_bases2 = <INFILE2>;
    chomp($num_bases2);
}
$num_bases2 =~ s/[^\d]//g;
print STDERR "num_bases2 = $num_bases2\n";
$num_bases_total = $num_bases1 + $num_bases2;
print STDERR "basereads_total= $num_bases_total\n";
print "basereads_total= $num_bases_total\n";
$norm_factor = $num_bases_total / 1000000000;
while($line1 = <INFILE1>) {
    $line2 = <INFILE2>;
    chomp($line1);
    chomp($line2);
    if($line1 =~ /(exon|intron|gene\t)/) {
	@a1 = split(/\t/,$line1);
	@a2 = split(/\t/,$line2);
	$count = $a1[2] + $a2[2];
	$ave_count = $a1[3] + $a2[3];
	$ave_norm = int($ave_count / $norm_factor * 1000) / 1000;
	print "$a1[0]\t$a1[1]\t$count\t$ave_count\t$ave_norm\t$a1[5]\n";
    }
    else {
	print "$line1\n";
    }
}

# basereads_total= 452323018
# --------------------------------------------------------------------
# uc003izx.2(hg19_ucsc_known_genes.txt)   -
#     Type        Location                Count   Ave_Cnt Ave_Nrm Length
#     gene        chr4_gl000193_random:49232-88374        0       0       0       1136
#   exon 1        chr4_gl000193_random:88199-88374        0       0       0       176
# intron 1        chr4_gl000193_random:75676-88197        0       0       0       12522

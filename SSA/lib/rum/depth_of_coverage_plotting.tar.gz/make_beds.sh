for i in {1..10}
do
    perl make_bed.pl RUM_Unique_split.$i RUM_Unique_split.$i.bed
done

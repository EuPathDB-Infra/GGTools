cp feature_quantifications_merged.1.txt feature_quantifications_merged.1-1.txt 
for i in {1..9}
do
    let j=$i+1
    perl merge_quantification_files.pl feature_quantifications_merged.1-$i.txt feature_quantifications_merged.$j.txt > feature_quantifications_merged.1-$j.txt
done

#!/usr/bin/perl

# Written by Gregory R. Grant
# University of Pennsylvania, 2010

# assuming a line of $ARGV[0] looks like this:
# seq.13392702    chr3    40576630-40576665, 40583257-40583328

if(@ARGV[0] < 1) {
    die "
Usage: perl get_stats_from_quantifications.pl <num>

expecting feature quantification files named as follows:

feature_quantifications_merged.1-1.txt
feature_quantifications_merged.1-2.txt
feature_quantifications_merged.1-3.txt
etc..

where <num> is the number of files

This script is part of the pipeline to build depth-of-coverage plots
from RUM_Unique files.  It probably should not be run outside of that
context.

This script is the final script in the pipeline that builds the
statistics from the progressively merged feature quantification files
that have been previously prepared.

";
}

for($filenumber=1; $filenumber<=$ARGV[0]; $filenumber++) {
    $filename = "feature_quantifications_merged.1-" . $filenumber . ".txt";
    open(INFILE, $filename);
    $num_bases = `head -1 $filename`;
    chomp($num_bases);
    $num_bases =~ s/[^\d]//g;
    while($line = <INFILE>) {
	if($line =~ /exon/) {
	    chomp($line);
	    @a = split(/\t/,$line);
	    $location = $a[1];
	    $ave_cnt = $a[3];
	    $exonhash{$location} = $ave_cnt;
	}
	if($line =~ /intron/) {
	    chomp($line);
	    @a = split(/\t/,$line);
	    $location = $a[1];
	    $ave_cnt = $a[3];
	    $intronhash{$location} = $ave_cnt;
	}
    }
    close(INFILE);
    $over_zero_count = 0;
    $over_one_count = 0;
    $over_five_count = 0;
    $total_exons = 0;
    foreach $location (keys %exonhash) {
	if($exonhash{$location} > 0) {
	    $over_zero_count++;
	}
	if($exonhash{$location} >= 1) {
	    $over_one_count++;
	}
	if($exonhash{$location} >= 5) {
	    $over_five_count++;
	}
	$total_exons++;
    }
    $over_zero_percent = int($over_zero_count / $total_exons * 1000) / 10;
    $over_one_percent = int($over_one_count / $total_exons * 1000) / 10;
    $over_five_percent = int($over_five_count / $total_exons * 1000) / 10;
    
    $t1 = format_large_int($num_bases);
    $t2 = format_large_int($over_zero_count);
    $t3 = format_large_int($over_one_count);
    $t4 = format_large_int($over_five_count);
    $num_frags = $filenumber * 5;
    $exon_out = $exon_out . "$num_frags\t$num_bases\t$over_zero_percent\t$over_one_percent\t$over_five_percent\n";
    $exon_out_formatted = $exon_out_formatted . "$num_frags\t$t1\t$t2 ($over_zero_percent%)\t$t3 ($over_one_percent%)\t$t4 ($over_five_percent%)\n";

    $over_zero_count = 0;
    $over_one_count = 0;
    $over_five_count = 0;
    $total_introns = 0;
    foreach $location (keys %intronhash) {
	if($intronhash{$location} > 0) {
	    $over_zero_count++;
	}
	if($intronhash{$location} >= 1) {
	    $over_one_count++;
	}
	if($intronhash{$location} >= 5) {
	    $over_five_count++;
	}
	$total_introns++;
    }
    $over_zero_percent = int($over_zero_count / $total_introns * 1000) / 10;
    $over_one_percent = int($over_one_count / $total_introns * 1000) / 10;
    $over_five_percent = int($over_five_count / $total_introns * 1000) / 10;
    
    $t1 = format_large_int($num_bases);
    $t2 = format_large_int($over_zero_count);
    $t3 = format_large_int($over_one_count);
    $t4 = format_large_int($over_five_count);

    $intron_out = $intron_out . "$num_frags\t$num_bases\t$over_zero_percent\t$over_one_percent\t$over_five_percent\n";
    $intron_out_formatted = $intron_out_formatted . "$num_frags\t$t1\t$t2 ($over_zero_percent%)\t$t3 ($over_one_percent%)\t$t4 ($over_five_percent%)\n";
}
$f = format_large_int($total_exons);
print "Total Number Exons: $f\n";
print "# Millions Frags\t# bases mapped uniquely\tAve Cov > 0\tAve Cov > 1\tAve Cov > 5\n";
print $exon_out;
print "\n";
print $exon_out_formatted;
print "\n";
$f = format_large_int($total_introns);
print "Total Number Introns: $f\n";
print "# Millions Frags\t# bases mapped uniquely\tAve Cov > 0\tAve Cov > 1\tAve Cov > 5\n";
print $intron_out;
print "\n";
print $intron_out_formatted;

sub format_large_int () {
    ($int) = @_;
    @a = split(//,"$int");
    $j=0;
    $newint = "";
    $n = @a;
    for($i=$n-1;$i>=0;$i--) {
	$j++;
	$newint = $a[$i] . $newint;
	if($j % 3 == 0) {
	    $newint = "," . $newint;
	}
    }
    $newint =~ s/^,//;
    return $newint;
}

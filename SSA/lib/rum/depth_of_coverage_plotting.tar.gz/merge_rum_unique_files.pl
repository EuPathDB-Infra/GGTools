#!/usr/bin/perl

# Written by Gregory R. Grant
# University of Pennsylvania, 2010

if(@ARGV < 2) {
    die "
Usage: merge_rum_unique_files.pl <rum unique files> <merged outfile>

";
}

$N = @ARGV;
open(OUTFILE, ">$ARGV[$N-1]");
$offset = 0;
for($i=0; $i<@ARGV-1; $i++) {
    open(INFILE, $ARGV[$i]);
    $max = 0;
    while($line = <INFILE>) {
	$line =~ /seq.(\d+)/;
	$seqnum = $1;
	$seqnum2 = $seqnum + $offset;
	$line =~ s/seq.$seqnum/seq.$seqnum2/;
	if($seqnum >= $max) {
	    $max = $seqnum;
	}
	print OUTFILE $line;
    }
    close(INFILE);
    $offset = $offset + $max;
}
close(OUTFILE);
